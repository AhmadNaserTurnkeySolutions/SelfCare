﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SelfCare.Entities;
using System.Runtime.Serialization.Json;
using System.Windows.Threading;
using System.Collections.ObjectModel;
using System.Collections.Generic;

namespace SelfCare.DAL
{
    public class RootObjectDao
    {
        public delegate List<Category> GalaxyDelegate();
        public event GalaxyDelegate GalaxyEvent;


        ObservableCollection<RootObject> MyDbset { set; get; }
        ObservableCollection<Category> MyCategories { set; get; }
        public Category[] cats { set; get; }
        public RootObjectDao() 
        {
            MyDbset = new ObservableCollection<RootObject>();
            MyCategories = new ObservableCollection<Category>();

        
            cats = new[] {
                                new Category(){
             id= 222221,
            slug= "c",
            title= "All",
            description= "",

            }
            ,
                new Category(){
             id= 21,
            slug= "c",
            title= "C#",
            description= "",

            },
                            new Category(){
             id= 16,
            slug= "c",
            title= "Programmers",
            description= "",

            },
                            new Category(){
             id= 1,
            slug= "c",
            title= "Programming",
            description= "",

            },
                            new Category(){
             id= 20,
            slug= "c",
            title= "SalesForce",
            description= "",

            },
                            new Category(){
             id= 17,
            slug= "c",
            title= "Study Abroad",
            description= "",

            },
                            new Category(){
             id= 18,
            slug= "c",
            title= "Tech",
            description= "",

            },
                            new Category(){
             id= 8,
            slug= "c",
            title= "Technical Articles",
            description= "",

            },
                            new Category(){
             id= 19,
            slug= "c",
            title= "Training",
            description= "",

            },
                            new Category(){
             id= 23,
            slug= "c",
            title= "WP7",
            description= "",

            }

            };

           


            //Loaded += delegate
            //{
            //    var uri = new Uri("http://ahmadnaser.com/?json=get_recent_posts&count=8&page=1");
            //    var request = (HttpWebRequest)HttpWebRequest.Create(uri);
            //    request.BeginGetResponse(HandleResponse, request);
            //};


        }

        public Category[] LoadCategories() 
        {
            var uri = new Uri("http://ahmadnaser.com/?json=get_category_index");
            var request = (HttpWebRequest)HttpWebRequest.Create(uri);


          //  request.BeginGetResponse(HandleCategoryResponse, request);


       
         

         Deployment.Current.Dispatcher.BeginInvoke(() =>
         {
             IAsyncResult result = request.BeginGetResponse(HandleCategoryResponse, request);
         }
               );


         return this.cats;

        // GalaxyDelegate DelegateHandler = new GalaxyDelegate(LoadCategories);

      //   this.GalaxyEvent += DelegateHandler;

         //List<Category> r = DelegateHandler.EndInvoke(result);

         
//public void finished (IAsyncResult r)
//{
//MyDel del = (MyDel)r.AsyncState;
//List<Student> l = del.EndInvoke(result);


//}





           //IAsyncResult result = GalaxyEvent.BeginInvoke( null, null);

           // // wait for it to complete
           // while (result.IsCompleted == false)
           // {
           //     // do some work
           //     //  Thread.Sleep(10);
           // }

           // // get the return value
           // List<Category> r = GalaxyEvent.EndInvoke(result);


           
        }

        public void LoadRecentPosts()
        {

            var uri = new Uri("http://ahmadnaser.com/?json=get_recent_posts&count=8&page=1");
            var request = (HttpWebRequest)HttpWebRequest.Create(uri);
            request.BeginGetResponse(HandleResponse, request);
        }

        public void LoadCategoryPerPost(int id)
        {

        }

        void HandleResponse(IAsyncResult ar)
        {
            var request = (HttpWebRequest)ar.AsyncState;

            //Normal Scenario 1 :: no getting objects
            /*
            using (var response = (HttpWebResponse)request.EndGetResponse(ar))
            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                var json = reader.ReadToEnd();

            }
             * */

            //Fancy Scenario 2 ::  getting objects
            using (var response = (HttpWebResponse)request.EndGetResponse(ar))
            {

                //Reference to System.ServiceModel.web
            
                var serializer = new DataContractJsonSerializer(typeof(RootObject));
                var items = (RootObject)serializer.ReadObject(response.GetResponseStream());
                //Dispatcher.BeginInvoke(() => DataContext = items.posts);


            }





        }











        void HandleCategoryResponse(IAsyncResult ar)
        {
            var request = (HttpWebRequest)ar.AsyncState;
           
        

         
            //Normal Scenario 1 :: no getting objects
            /*
            using (var response = (HttpWebResponse)request.EndGetResponse(ar))
            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                var json = reader.ReadToEnd();

            }
             * */

            //Fancy Scenario 2 ::  getting objects
            using (var response = (HttpWebResponse)request.EndGetResponse(ar))
            {

              

                var serializer = new DataContractJsonSerializer(typeof(CategoryRootObject));
                CategoryRootObject CategoryRootObject = (CategoryRootObject)serializer.ReadObject(response.GetResponseStream());
                //Dispatcher.BeginInvoke(() => DataContext = items.posts);

                int i = 0;
                foreach (var c in CategoryRootObject.categories)
                {
                    MyCategories.Add(c);
                    cats[i] = new Category() { id = c.id, title = "qwewe" + c.title };
                    i++;
                }
               

                
            }


         
            

        }









     
    }
}
